/**
* MyCubeMap
* @constructor
*/
class MyCubeMap extends CGFobject {
    constructor(scene) {
        super(scene);

        this.square = new MyPlane(scene,40);

        this.initMaterials();
    }

    initMaterials(){
        //Mountain LandScape
        this.landScapeFront = new CGFappearance(this.scene);
        this.landScapeFront.setAmbient(1, 1, 1, 1);
        this.landScapeFront.setDiffuse(0, 0, 0, 1);
        this.landScapeFront.setSpecular(0, 0, 0, 1);
        this.landScapeFront.setShininess(10.0);
        this.landScapeFront.loadTexture('images/split_cubemap/front.png');
        this.landScapeFront.setTextureWrap('REPEAT', 'REPEAT');

        this.landScapeRight = new CGFappearance(this.scene);
        this.landScapeRight.setAmbient(1, 1, 1, 1);
        this.landScapeRight.setDiffuse(0, 0, 0, 1);
        this.landScapeRight.setSpecular(0, 0, 0, 1);
        this.landScapeRight.setShininess(10.0);
        this.landScapeRight.loadTexture('images/split_cubemap/right.png');
        this.landScapeRight.setTextureWrap('REPEAT', 'REPEAT');

        this.landScapeBack = new CGFappearance(this.scene);
        this.landScapeBack.setAmbient(1, 1, 1, 1);
        this.landScapeBack.setDiffuse(0, 0, 0, 1);
        this.landScapeBack.setSpecular(0, 0, 0, 1);
        this.landScapeBack.setShininess(10.0);
        this.landScapeBack.loadTexture('images/split_cubemap/back.png');
        this.landScapeBack.setTextureWrap('REPEAT', 'REPEAT');

        this.landScapeLeft = new CGFappearance(this.scene);
        this.landScapeLeft.setAmbient(1, 1, 1, 1);
        this.landScapeLeft.setDiffuse(0, 0, 0, 1);
        this.landScapeLeft.setSpecular(0, 0, 0, 1);
        this.landScapeLeft.setShininess(10.0);
        this.landScapeLeft.loadTexture('images/split_cubemap/left.png');
        this.landScapeLeft.setTextureWrap('REPEAT', 'REPEAT');

        this.landScapeBottom = new CGFappearance(this.scene);
        this.landScapeBottom.setAmbient(1, 1, 1, 1);
        this.landScapeBottom.setDiffuse(0, 0, 0, 1);
        this.landScapeBottom.setSpecular(0, 0, 0, 1);
        this.landScapeBottom.setShininess(10.0);
        this.landScapeBottom.loadTexture('images/split_cubemap/bottom.png');
        this.landScapeBottom.setTextureWrap('REPEAT', 'REPEAT');

        this.landScapeTop = new CGFappearance(this.scene);
        this.landScapeTop.setAmbient(1, 1, 1, 1);
        this.landScapeTop.setDiffuse(0, 0, 0, 1);
        this.landScapeTop.setSpecular(0, 0, 0, 1);
        this.landScapeTop.setShininess(10.0);
        this.landScapeTop.loadTexture('images/split_cubemap/top.png');
        this.landScapeTop.setTextureWrap('REPEAT', 'REPEAT');

        //Beach LandScape
        this.landScapeBeachFront = new CGFappearance(this.scene);
        this.landScapeBeachFront.setAmbient(1, 1, 1, 1);
        this.landScapeBeachFront.setDiffuse(0, 0, 0, 1);
        this.landScapeBeachFront.setSpecular(0, 0, 0, 1);
        this.landScapeBeachFront.setShininess(10.0);
        this.landScapeBeachFront.loadTexture('images/split_cubemap/beachFront.png');
        this.landScapeBeachFront.setTextureWrap('REPEAT', 'REPEAT');

        this.landScapeBeachRight = new CGFappearance(this.scene);
        this.landScapeBeachRight.setAmbient(1, 1, 1, 1);
        this.landScapeBeachRight.setDiffuse(0, 0, 0, 1);
        this.landScapeBeachRight.setSpecular(0, 0, 0, 1);
        this.landScapeBeachRight.setShininess(10.0);
        this.landScapeBeachRight.loadTexture('images/split_cubemap/beachRight.png');
        this.landScapeBeachRight.setTextureWrap('REPEAT', 'REPEAT');

        this.landScapeBeachBack = new CGFappearance(this.scene);
        this.landScapeBeachBack.setAmbient(1, 1, 1, 1);
        this.landScapeBeachBack.setDiffuse(0, 0, 0, 1);
        this.landScapeBeachBack.setSpecular(0, 0, 0, 1);
        this.landScapeBeachBack.setShininess(10.0);
        this.landScapeBeachBack.loadTexture('images/split_cubemap/beachBack.png');
        this.landScapeBeachBack.setTextureWrap('REPEAT', 'REPEAT');

        this.landScapeBeachLeft = new CGFappearance(this.scene);
        this.landScapeBeachLeft.setAmbient(1, 1, 1, 1);
        this.landScapeBeachLeft.setDiffuse(0, 0, 0, 1);
        this.landScapeBeachLeft.setSpecular(0, 0, 0, 1);
        this.landScapeBeachLeft.setShininess(10.0);
        this.landScapeBeachLeft.loadTexture('images/split_cubemap/beachLeft.png');
        this.landScapeBeachLeft.setTextureWrap('REPEAT', 'REPEAT');

        this.landScapeBeachBottom = new CGFappearance(this.scene);
        this.landScapeBeachBottom.setAmbient(1, 1, 1, 1);
        this.landScapeBeachBottom.setDiffuse(0, 0, 0, 1);
        this.landScapeBeachBottom.setSpecular(0, 0, 0, 1);
        this.landScapeBeachBottom.setShininess(10.0);
        this.landScapeBeachBottom.loadTexture('images/split_cubemap/beachBottom.png');
        this.landScapeBeachBottom.setTextureWrap('REPEAT', 'REPEAT');

        this.landScapeBeachTop = new CGFappearance(this.scene);
        this.landScapeBeachTop.setAmbient(1, 1, 1, 1);
        this.landScapeBeachTop.setDiffuse(0, 0, 0, 1);
        this.landScapeBeachTop.setSpecular(0, 0, 0, 1);
        this.landScapeBeachTop.setShininess(10.0);
        this.landScapeBeachTop.loadTexture('images/split_cubemap/beachTop.png');
        this.landScapeBeachTop.setTextureWrap('REPEAT', 'REPEAT');
    }

    display() {

        var ini = [1,0,0,0,
                  0,1,0,0,
                  0,0,1,0,
                  0,0,0,1];

    this.scene.multMatrix(ini);

    //Mostra a parte da frente do CubeMap
    this.scene.pushMatrix();
    if(this.scene.selectedLandScape == 0)
        this.landScapeFront.apply();
    else
        this.landScapeBeachFront.apply();
    this.scene.translate(0, 0, -24.9);
    this.scene.scale(50, 50, 1);
    this.square.display();
    this.scene.popMatrix();

    this.scene.pushMatrix();
    if(this.scene.selectedLandScape == 0)
        this.landScapeRight.apply();
    else
        this.landScapeBeachRight.apply();
    this.scene.translate(24.9, 0, 0);
    this.scene.rotate(-Math.PI/2.0, 0, 1, 0);
    this.scene.scale(50, 50, 1);
    this.square.display();
    this.scene.popMatrix();

    this.scene.pushMatrix();
    if(this.scene.selectedLandScape == 0)
        this.landScapeBack.apply();
    else
        this.landScapeBeachBack.apply();
    this.scene.translate(0, 0, 24.9);
    this.scene.scale(50, 50, 1);
    this.scene.rotate(Math.PI, 0, 1, 0);
    this.square.display();
    this.scene.popMatrix();

    this.scene.pushMatrix();
    if(this.scene.selectedLandScape == 0)
        this.landScapeLeft.apply();
    else
        this.landScapeBeachLeft.apply();
    this.scene.translate(-24.9, 0, 0);
    this.scene.rotate(Math.PI/2.0, 0, 1, 0);
    this.scene.scale(50, 50, 1);
    this.square.display();
    this.scene.popMatrix();

    this.scene.pushMatrix();
    if(this.scene.selectedLandScape == 0)
        this.landScapeTop.apply();
    else
        this.landScapeBeachTop.apply();
    this.scene.translate(0, 24.9, 0);
    this.scene.rotate(Math.PI/2.0, 1, 0, 0);
    this.scene.scale(50, 50, 1);
    this.square.display();
    this.scene.popMatrix();

    this.scene.pushMatrix();
    if(this.scene.selectedLandScape == 0)
        this.landScapeBottom.apply();
    else
        this.landScapeBeachBottom.apply();
    this.scene.translate(0, -24.9, 0);
    this.scene.rotate(-Math.PI/2.0, 1, 0, 0);
    this.scene.scale(50, 50, 1);
    this.square.display();
    this.scene.popMatrix();
   
    }

    enableNormalViz(){
            this.square.enableNormalViz();
    }

    disableNormalViz(){
            this.square.disableNormalViz();
    }

    
}
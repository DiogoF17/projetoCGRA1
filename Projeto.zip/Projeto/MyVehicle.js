/**
* MyVehicle
* @constructor
*/
class MyVehicle extends CGFobject {
    constructor(scene, ang_YY, x, y, z) {
        super(scene);

        this.ang_YY = ang_YY;   //orientacao do veiculo
        this.vel = 0;           //velocidade do veiculo inicialmente 0
        this.x = x;             //posicao do veiculo em x
        this.y = y;             //posicao do veiculo em y
        this.z = z;             //posicao do veiculo em z

        //Guarda os valores das coordenadas iniciais
        this.xi = this.x;
        this.yi = this.y;
        this.zi = this.z;
        this.angi = this.ang_YY;

        this.resetVehicle = false;

        this.triangle = new MyTriangle(scene);

    }

    //initMaterials(){}

    display() {

        var ini = [1,0,0,0,
                    0,1,0,0,
                    0,0,1,0,
                    0,0,0,1];

        this.scene.multMatrix(ini);

        this.scene.pushMatrix();
        this.scene.translate(this.x, this.y, this.z);
        this.scene.rotate(this.ang_YY, 0, 1, 0);
        this.triangle.display();
        this.scene.popMatrix();
    
    }

    update(){
        if (!this.resetVehicle){
            this.x += Math.sin(this.ang_YY) * this.vel;
            this.z += Math.cos(this.ang_YY) * this.vel;
        }else{
            this.resetVehicle =false;
        }
        this.display();
    }

    turn(val){
        this.ang_YY += Math.PI * val / 180;
    }

    accelerate(val){
        this.vel += val;
    }

    reset(){
        this.x = this.xi;
        this.y = this.yi;
        this.z = this.zi;
        this.ang_YY = this.angi;
        this.vel = 0; 
        this.resetVehicle = true;
    }

    enableNormalViz(){
            this.triangle.enableNormalViz();
    }

    disableNormalViz(){
            this.triangle.disableNormalViz();
    }

    
}
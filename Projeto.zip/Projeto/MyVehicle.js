/**
* MyVehicle
* @constructor
*/
class MyVehicle extends CGFobject {
    constructor(scene, ang_YY, x, y, z) {
        super(scene);
        
        this.ang_YY = ang_YY;   //orientacao do veiculo
        this.vel = 0;           //velocidade do veiculo inicialmente 0
        this.x = x;             //posicao do veiculo em x
        this.y = y;             //posicao do veiculo em y
        this.z = z;             //posicao do veiculo em z

        //Guarda os valores das coordenadas iniciais
        this.xi = this.x;
        this.yi = this.y;
        this.zi = this.z;

        this.direcaoLeme = 0;
        this.lastAng = 0;

        this.resetVehicle = false;
        this.pilotoAutomatico = false;

        this.dirigivel = new MyDirigivel(this.scene);
        this.flag = new MyPlane(this.scene, 40);
        this.flagHolder = new MySquare(this.scene);

        this.flagPort = new CGFtexture(this.scene, "images/bandPort.png");
        this.flagPortReflected = new CGFtexture(this.scene, "images/bandPortReflected.png");
        
        this.white = new CGFappearance(this.scene);
        this.white.setAmbient(1, 1, 1, 1);
        this.white.setDiffuse(0, 0, 0, 1);
        this.white.setSpecular(0, 0, 0, 1);
        this.white.setShininess(10.0);
        this.white.loadTexture('images/Nomes.png');
        this.white.setTextureWrap('REPEAT', 'REPEAT');

        this.flagShader = new CGFshader(this.scene.gl, "flag.vert", "flag.frag");
        this.flagShaderOtherSide = new CGFshader(this.scene.gl, "flagOtherSide.vert", "flagOtherSide.frag");
        this.flagShader.setUniformsValues({ period: 2 * Math.PI});
        this.flagShaderOtherSide.setUniformsValues({ period: 2 * Math.PI});
        this.flagShader.setUniformsValues({uSampler1: 0});
        this.flagShaderOtherSide.setUniformsValues({uSampler2: 1});
        
        this.i = 0;
    }

    moveFlag(){
        var velocityOfFlag = Math.ceil(Math.abs(this.vel)* 10 * this.scene.speedFactorVehicle);
        this.i = this.i % ((14-velocityOfFlag)*2);
    
        this.flagShader.setUniformsValues({ desloc: Math.PI/(14-velocityOfFlag) * this.i });
        this.flagShaderOtherSide.setUniformsValues({ desloc: Math.PI/(14-velocityOfFlag) * this.i });
        this.flagShader.setUniformsValues({ dif: Math.sin(Math.PI/(14-velocityOfFlag) * this.i) * 0.2});
        this.flagShaderOtherSide.setUniformsValues({ dif: Math.sin(Math.PI/(14-velocityOfFlag) * this.i) * 0.2});
        this.flagShader.setUniformsValues({ normScale: this.scene.scaleFactorVehicle});
        this.flagShaderOtherSide.setUniformsValues({ normScale: this.scene.scaleFactorVehicle});
      
        this.i++;
    }

    update(){

        if(!this.pilotoAutomatico){
            if (!this.resetVehicle){
                this.x += Math.sin(this.ang_YY) * this.vel * this.scene.speedFactorVehicle;
                this.z += Math.cos(this.ang_YY) * this.vel * this.scene.speedFactorVehicle;
            }else{
                this.resetVehicle =false;
            }
            this.dirigivel.update(this.vel, this.direcaoLeme);
            this.direcaoLeme = 0;
            this.display();
        }
        else{
            this.dirigivel.update(1, -1);
            this.ang_YY += Math.PI * 3.1 / 180;
            this.direcaoLeme = 0;
            this.display();
        }
    }

    turn(val){
        if(!this.pilotoAutomatico){
            this.ang_YY += Math.PI * val / 180;
            if (this.vel>=0){
                if(val > 0){
                    this.direcaoLeme += -1;
                }
                else{
                    this.direcaoLeme += 1;
                }
            }else{
                if(val > 0){
                    this.direcaoLeme += 1;
                }
                else{
                    this.direcaoLeme += -1;
                }
            }
        }
    }

    accelerate(val){
        if(!this.pilotoAutomatico)
            this.vel += val;
    }

    reset(){
        this.x = this.xi;
        this.y = this.yi;
        this.z = this.zi;

        this.ang_YY = 0; 
        this.vel = 0; 
        this.resetVehicle = true;
        this.pilotoAutomatico = false
    }

    activatePilotoAutomatico(){
        if(!this.pilotoAutomatico){
            this.pilotoAutomatico = true;
            this.xPil = this.x + (5* Math.cos(this.ang_YY));
            this.zPil = this.z - (5* Math.sin(this.ang_YY));
        }
    }

    display() {

        var ini = [1,0,0,0,
                    0,1,0,0,
                    0,0,1,0,
                    0,0,0,1];

        this.scene.multMatrix(ini);

        if(!this.pilotoAutomatico){
            //faz display do dirigivel
            this.scene.pushMatrix();
            this.scene.translate(this.x, this.y, this.z);
            this.scene.translate(0, 10, 0);
            this.scene.rotate(this.ang_YY, 0, 1, 0);
            this.dirigivel.display();
            this.scene.popMatrix();

            //faz display da bandeira
            this.flagPort.bind(0);
            this.flagPortReflected.bind(1);

            this.scene.setActiveShader(this.flagShader);
            
            this.scene.pushMatrix();
            this.scene.translate(this.x, this.y, this.z);
            this.scene.translate(-2.8*Math.sin(this.ang_YY), 10, -2.8*Math.cos(this.ang_YY));
            this.scene.rotate(this.ang_YY, 0, 1, 0);
            this.scene.rotate(Math.PI/2.0, 0, 1, 0);
            this.scene.scale(1, 0.5, 1);
            this.flag.display();
            this.scene.popMatrix();

            this.scene.setActiveShader(this.flagShaderOtherSide);

            this.scene.pushMatrix();
            this.scene.translate(this.x, this.y, this.z);
            this.scene.translate(-2.8*Math.sin(this.ang_YY), 10, -2.8*Math.cos(this.ang_YY));
            this.scene.rotate(this.ang_YY, 0, 1, 0);
            this.scene.rotate(Math.PI, 0, 1, 0);
            this.scene.rotate(Math.PI/2.0, 0, 1, 0);
            this.scene.scale(1, 0.5, 1);
            this.flag.display();
            this.scene.popMatrix();

            this.scene.setActiveShader(this.scene.defaultShader);

            //faz display das hastes da bandeira
            this.scene.pushMatrix();
            this.scene.translate(this.x, this.y, this.z);
            this.scene.translate(-1.8*Math.sin(this.ang_YY), 10.2, -1.8*Math.cos(this.ang_YY));
            this.scene.rotate(this.ang_YY, 0, 1, 0);
            this.scene.rotate(Math.PI/2.0, 1, 0, 0);
            this.scene.rotate(Math.PI/2.0, 0, 0, 1);
            this.scene.scale(1, 0.1, 1);
            this.white.apply();
            this.flagHolder.display();
            this.scene.popMatrix();
        
            this.scene.pushMatrix();
            this.scene.translate(this.x, this.y, this.z);
            this.scene.translate(-1.8*Math.sin(this.ang_YY), 9.8, -1.8*Math.cos(this.ang_YY));
            this.scene.rotate(this.ang_YY, 0, 1, 0);
            this.scene.rotate(Math.PI/2.0, 1, 0, 0);
            this.scene.rotate(Math.PI/2.0, 0, 0, 1);
            this.scene.scale(1, 0.1, 1);
            this.white.apply();
            this.flagHolder.display();
            this.scene.popMatrix();
        }
        else{
            //faz display do dirigivel
            this.scene.pushMatrix();
            this.scene.translate(this.xPil, 0, this.zPil);
            this.scene.translate(0, 10, 0);
            this.scene.translate(-5 * Math.cos(this.ang_YY), 0, 5 * Math.sin(this.ang_YY));
            this.scene.rotate(this.ang_YY, 0, 1, 0);
            this.dirigivel.display();
            this.scene.popMatrix();

            //faz display da bandeira
            this.flagPort.bind(0);
            this.flagPortReflected.bind(1);

            this.scene.setActiveShader(this.flagShader);

            this.scene.pushMatrix();
            this.scene.translate(this.xPil, 0, this.zPil);
            this.scene.translate(-5 * Math.cos(this.ang_YY), 0, 5 * Math.sin(this.ang_YY));
            this.scene.translate(-2.8*Math.sin(this.ang_YY), 10, -2.8*Math.cos(this.ang_YY));
            this.scene.rotate(this.ang_YY, 0, 1, 0);
            this.scene.rotate(Math.PI/2.0, 0, 1, 0);
            this.scene.scale(1, 0.5, 1);
            this.flag.display();
            this.scene.popMatrix();

            this.scene.setActiveShader(this.flagShaderOtherSide);

            this.scene.pushMatrix();
            this.scene.translate(this.xPil, 0, this.zPil);
            this.scene.translate(-5 * Math.cos(this.ang_YY), 0, 5 * Math.sin(this.ang_YY));
            this.scene.translate(-2.8*Math.sin(this.ang_YY), 10, -2.8*Math.cos(this.ang_YY));
            this.scene.rotate(this.ang_YY, 0, 1, 0);
            this.scene.rotate(-Math.PI/2.0, 0, 1, 0);
            this.scene.scale(1, 0.5, 1);
            this.flag.display();
            this.scene.popMatrix();

            this.scene.setActiveShader(this.scene.defaultShader);

            //faz display das hastes da bandeira
            this.scene.pushMatrix();
            this.scene.translate(this.xPil, 0, this.zPil);
            this.scene.translate(-5 * Math.cos(this.ang_YY), 0, 5 * Math.sin(this.ang_YY));
            this.scene.translate(-1.8*Math.sin(this.ang_YY), 10.2, -1.8*Math.cos(this.ang_YY));
            this.scene.rotate(this.ang_YY, 0, 1, 0);
            this.scene.rotate(Math.PI/2.0, 1, 0, 0);
            this.scene.rotate(Math.PI/2.0, 0, 0, 1);
            this.scene.scale(1, 0.1, 1);
            this.white.apply();
            this.flagHolder.display();
            this.scene.popMatrix();
        
            this.scene.pushMatrix();
            this.scene.translate(this.xPil, 0, this.zPil);
            this.scene.translate(-5 * Math.cos(this.ang_YY), 0, 5 * Math.sin(this.ang_YY));
            this.scene.translate(-1.8*Math.sin(this.ang_YY), 9.8, -1.8*Math.cos(this.ang_YY));
            this.scene.rotate(this.ang_YY, 0, 1, 0);
            this.scene.rotate(Math.PI/2.0, 1, 0, 0);
            this.scene.rotate(Math.PI/2.0, 0, 0, 1);
            this.scene.scale(1, 0.1, 1);
            this.white.apply();
            this.flagHolder.display();
            this.scene.popMatrix();
        }

    }

    enableNormalViz(){
            this.sphere.enableNormalViz();
    }

    disableNormalViz(){
            this.sphere.disableNormalViz();
    }

}
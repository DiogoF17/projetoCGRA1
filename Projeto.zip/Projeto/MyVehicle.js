/**
* MyVehicle
* @constructor
*/
class MyVehicle extends CGFobject {
    constructor(scene, ang_YY, x, y, z) {
        super(scene);

        this.ang_YY = ang_YY;   //orientacao do veiculo
        this.vel = 0;           //velocidade do veiculo inicialmente 0
        this.x = x;             //posicao do veiculo em x
        this.y = y;             //posicao do veiculo em y
        this.z = z;             //posicao do veiculo em z

        //Guarda os valores das coordenadas iniciais
        this.xi = this.x;
        this.yi = this.y;
        this.zi = this.z;

        this.direcaoLeme = 0;
        this.lastAng = 0;

        this.resetVehicle = false;
        this.pilotoAutomatico = false;

        this.dirigivel = new MyDirigivel(this.scene);

    }

    update(){
        if(!this.pilotoAutomatico){
            if (!this.resetVehicle){
                this.x += Math.sin(this.ang_YY) * this.vel * this.scene.speedFactorVehicle;
                this.z += Math.cos(this.ang_YY) * this.vel * this.scene.speedFactorVehicle;
            }else{
                this.resetVehicle =false;
            }
            this.dirigivel.update(this.vel, this.direcaoLeme);
            this.direcaoLeme = 0;
            this.display();
        }
        else{
            this.dirigivel.update(1, -1);
            this.ang_YY += Math.PI * 3.1 / 180;
            this.direcaoLeme = 0;
            this.display();
        }
    }

    turn(val){
        if(!this.pilotoAutomatico){
            this.ang_YY += Math.PI * val / 180;
            if (this.vel>=0){
                if(val > 0){
                    this.direcaoLeme = -1;
                }
                else{
                    this.direcaoLeme = 1;
                }
            }else{
                if(val > 0){
                    this.direcaoLeme = 1;
                }
                else{
                    this.direcaoLeme = -1;
                }
            }
        }
    }

    accelerate(val){
        if(!this.pilotoAutomatico)
            this.vel += val;
    }

    reset(){
        this.x = this.xi;
        this.y = this.yi;
        this.z = this.zi;

        this.ang_YY = 0; 
        this.vel = 0; 
        this.resetVehicle = true;
        this.pilotoAutomatico = false;
    }

    activatePilotoAutomatico(){
        if(!this.pilotoAutomatico){
            this.pilotoAutomatico = true;
            this.xPil =this.x + (5* Math.cos(this.ang_YY));
            this.zPil =this.z - (5* Math.sin(this.ang_YY));
        }
    }

    display() {

        var ini = [1,0,0,0,
                    0,1,0,0,
                    0,0,1,0,
                    0,0,0,1];

        this.scene.multMatrix(ini);

        if(!this.pilotoAutomatico){
            this.scene.pushMatrix();
            this.scene.translate(this.x, this.y, this.z);
            this.scene.translate(0, 10, 0);
            this.scene.rotate(this.ang_YY, 0, 1, 0);
            this.dirigivel.display();
            this.scene.popMatrix();
        }
        else{
            this.scene.pushMatrix();
            this.scene.translate(this.xPil, 0, this.zPil);
            this.scene.translate(0, 10, 0);
            this.scene.translate(-5 * Math.cos(this.ang_YY), 0, 5 * Math.sin(this.ang_YY));
            this.scene.rotate(this.ang_YY, 0, 1, 0);
            this.dirigivel.display();
            this.scene.popMatrix();
        }
    }

    enableNormalViz(){
            this.sphere.enableNormalViz();
    }

    disableNormalViz(){
            this.sphere.disableNormalViz();
    }

    
}
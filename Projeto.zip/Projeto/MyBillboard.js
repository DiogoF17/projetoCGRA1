/**
* MyVehicle
* @constructor
*/
class MyBillboard extends CGFobject {
    constructor(scene) {
        super(scene);
        
        this.tabuleta = new MyPlane(this.scene, 40);
        this.barra = new MyPlane(this.scene, 40);
        this.estaca = new MyPlane(this.scene, 40);

        this.texTab = new CGFappearance(this.scene);
        this.texTab.setAmbient(1, 1, 1, 1);
        this.texTab.setDiffuse(0, 0, 0, 1);
        this.texTab.setSpecular(0, 0, 0, 1);
        this.texTab.setShininess(10.0);
        this.texTab.loadTexture('images/planoSuppliesDelivered.png');
        this.texTab.setTextureWrap('REPEAT', 'REPEAT');

        this.texBarra = new CGFtexture(this.scene, "images/barraSuppliesDelivered.png");

        /*this.flagShader = new CGFshader(this.scene.gl, "flag.vert", "flag.frag");
        this.flagShaderOtherSide = new CGFshader(this.scene.gl, "flagOtherSide.vert", "flagOtherSide.frag");
        this.flagShader.setUniformsValues({ period: 2 * Math.PI});
        this.flagShaderOtherSide.setUniformsValues({ period: 2 * Math.PI});
        this.flagShader.setUniformsValues({uSampler1: 0});
        this.flagShaderOtherSide.setUniformsValues({uSampler2: 1});*/

    }

    display() {

        var ini = [1,0,0,0,
                    0,1,0,0,
                    0,0,1,0,
                    0,0,0,1];

        this.scene.multMatrix(ini);

        
        this.scene.pushMatrix();
        this.scene.scale(2, 1, 1);
        this.scene.rotate(Math.PI/4, 0, 1, 0);
        this.texTab.apply();
        this.tabuleta.display();
        this.scene.popMatrix();
    }

    enableNormalViz(){
            this.sphere.enableNormalViz();
    }

    disableNormalViz(){
            this.sphere.disableNormalViz();
    }

}

const SupplyStates = { 
    INACTIVE: 0,
    FALLING: 1, 
    LANDED: 2
 };

class MySupply extends CGFobject {

	constructor(scene) {
		super(scene);
        
        this.plane = new MyPlane(this.scene, 6);
        this.state = SupplyStates.INACTIVE;

        this.velQueda= 0;
        this.posX;
        this.posY;
        this.posZ;

        this.Material = new CGFappearance(this.scene);
        this.Material.setAmbient(1,1, 1, 1);
        this.Material.setDiffuse(0, 0, 0, 1);
        this.Material.setSpecular(0, 0, 0, 1);
        this.Material.setShininess(10.0);
        this.Material.loadTexture('images/caixa.jpg');
        this.Material.setTextureWrap('REPEAT', 'REPEAT');
        
	}
	display(){
        
        if (this.state != SupplyStates.INACTIVE){
            if (this.state== SupplyStates.FALLING)
                this.displayFalling();
            else
                this.displayLanded();
        }
    }

    displayFalling(){

        this.Material.apply();

        this.scene.pushMatrix();
        this.scene.translate(this.posX,this.posY,this.posZ);
        this.scene.scale(0.5,0.5,0.5);

        this.scene.pushMatrix();
        this.scene.translate(0,0,0.5);
        this.plane.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(-0.5,0,0);
        this.scene.rotate( (-Math.PI/2.0), 0, 1, 0 );
        this.plane.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(0.5,0,0);
        this.scene.rotate( (Math.PI/2.0), 0, 1, 0 );
        this.plane.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(0,0,-0.5);
        this.scene.rotate( (Math.PI), 0, 1, 0 );
        this.plane.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(0,-0.5,0);
        this.scene.rotate( (Math.PI/2.0), 1, 0, 0 );
        this.plane.display();
        this.scene.popMatrix();


        this.scene.pushMatrix();
        this.scene.translate(0,0.5,0);
        this.scene.rotate( (-Math.PI/2.0), 1, 0, 0 );
        this.plane.display();
        this.scene.popMatrix();

        this.scene.popMatrix();
    }

    displayLanded(){
        
        this.Material.apply();
        
        this.scene.pushMatrix();
        this.scene.translate(this.posX,0.01,this.posZ);
        this.scene.rotate( -(Math.PI/2.0), 1, 0, 0 );
        this.plane.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(this.posX,0.01,1+this.posZ);
        this.scene.rotate( -(Math.PI/2.0), 1, 0, 0 );
        this.plane.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(this.posX,0.01,-1+this.posZ);
        this.scene.rotate( -(Math.PI/2.0), 1, 0, 0 );
        this.plane.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(1+this.posX,0.01,this.posZ);
        this.scene.rotate( -(Math.PI/2.0), 1, 0, 0 );
        this.plane.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(-1+this.posX,0.01,1+this.posZ);
        this.scene.rotate( -(Math.PI/2.0), 1, 0, 0 );
        this.plane.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(this.posX,0.01,-2+this.posZ);
        this.scene.rotate( -(Math.PI/2.0), 1, 0, 0 );
        this.plane.display();
        this.scene.popMatrix();

    }

    update(){
        if(this.state == SupplyStates.FALLING){
            if (this.posY > 0.1){
                this.posY -= this.velQueda;
            }
            else{
               this.land();
            }
        }
    }

    drop(x, z){
        if (this.state == SupplyStates.INACTIVE){
            this.state = SupplyStates.FALLING;
            this.velQueda = 0.17;
            this.posX = x;
            this.posY = 8.55;
            this.posZ = z;
        }
    }

    land(){
        this.state = SupplyStates.LANDED;
    }

    reset(){
        this.velQueda= 0;
        this.state = SupplyStates.INACTIVE;
    }

    
    enableNormalViz(){
        this.plane.enableNormalViz();
    }

    disableNormalViz(){
        this.plane.disableNormalViz();
    }
}
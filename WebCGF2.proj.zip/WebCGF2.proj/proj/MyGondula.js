/**
* MyTriangle
* @constructor
*/
class MyGondula extends CGFobject {
    constructor(scene) {
        super(scene);

        this.sphere = new MySphere(this.scene, 50, 50);
        this.cylinder = new MyCylinder(this.scene, 50, 25);
        this.square = new MySquare(this.scene);

        this.ang = 0;
    }

    update(vel){
        this.ang += (Math.PI * 15  / 180) * vel * 10;
    } 

    display() {

        var ini = [1,0,0,0,
                    0,1,0,0,
                    0,0,1,0,
                    0,0,0,1];

        this.scene.multMatrix(ini);

        this.scene.pushMatrix();
        this.scene.scale(0.2, 0.2, 1);
        this.scene.rotate(Math.PI/2, 1, 0, 0);
        this.cylinder.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.scale(0.2, 0.2, 0.3);
        this.sphere.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(0, 0, 1);
        this.scene.scale(0.2, 0.2, 0.3);
        this.sphere.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(0.2, 0, -0.1);
        this.scene.scale(0.1, 0.1, 0.2);
        this.sphere.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(-0.2, 0, -0.1);
        this.scene.scale(0.1, 0.1, 0.2);
        this.sphere.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(0.2, 0, -0.3);
        this.scene.rotate(this.ang, 0, 0, 1);
        this.scene.scale(0.03, 0.25, 1);
        this.square.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(-0.2, 0, -0.3);
        this.scene.rotate(this.ang, 0, 0, 1);
        this.scene.scale(0.03, 0.25, 1);
        this.square.display();
        this.scene.popMatrix();
    
    }
    
}
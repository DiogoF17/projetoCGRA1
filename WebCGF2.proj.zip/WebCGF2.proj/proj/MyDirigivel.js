/**
* MyVehicle
* @constructor
*/
class MyDirigivel extends CGFobject {
    constructor(scene) {
        super(scene);

        this.sphere = new MySphere(this.scene, 50, 50);
        this.lemes = new MyLemes(this.scene);
        this.gondula = new MyGondula(this.scene);

        this.direcaoLeme = 0;

    }

    update(vel, direcaoLeme){
        this.gondula.update(vel);
        
        this.direcaoLeme = direcaoLeme;
    }

    display() {

        var ini = [1,0,0,0,
                    0,1,0,0,
                    0,0,1,0,
                    0,0,0,1];

        this.scene.multMatrix(ini);

        this.scene.pushMatrix();
        this.scene.scale(1, 1, 2);
        this.sphere.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(0, 0.8, -1.4);
        this.scene.scale(1, 0.6, 0.8);
        this.scene.rotate(this.direcaoLeme * Math.PI * 30 / 180, 0, 1, 0);
        this.lemes.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(0, -0.8, -1.4);
        this.scene.rotate(Math.PI, 0, 0, 1);
        this.scene.scale(1, 0.6, 0.8);
        this.scene.rotate(-this.direcaoLeme * Math.PI * 30 / 180, 0, 1, 0);
        this.lemes.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(-0.8, 0, -1.4);
        this.scene.rotate(Math.PI/2, 0, 0, 1);
        this.scene.scale(1, 0.6, 0.8);
        this.lemes.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(0.8, 0, -1.4);
        this.scene.rotate(-Math.PI/2, 0, 0, 1);
        this.scene.scale(1, 0.6, 0.8);
        this.lemes.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(0, -1, -0.5);
        this.gondula.display();
        this.scene.popMatrix();
    
    }

    enableNormalViz(){
            this.sphere.enableNormalViz();
    }

    disableNormalViz(){
            this.sphere.disableNormalViz();
    }

    
}
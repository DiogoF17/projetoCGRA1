/**
* MyScene
* @constructor
*/
class MyScene extends CGFscene {
    constructor() {
        super();
    }
    init(application) {
        super.init(application);
        this.initCameras();
        this.initLights();

        //Background color
        this.gl.clearColor(0.0, 0.0, 0.0, 1.0);

        this.gl.clearDepth(100.0);
        this.gl.enable(this.gl.DEPTH_TEST);
        this.gl.enable(this.gl.CULL_FACE);
        this.gl.depthFunc(this.gl.LEQUAL);

        this.setUpdatePeriod(50);
        
        this.enableTextures(true);

        //Initialize scene objects
        this.axis = new CGFaxis(this);
        this.sphere = new MySphere(this, 50, 50);
        this.cylinder = new MyCylinder(this, 50,25);
        this.plane = new MyPlane(this, 16);
        this.cubeMap = new MyCubeMap(this);
        this.vehicle = new MyVehicle(this, 0, 0, 0, 0);

        //Textutes
        this.worldTxt = new CGFappearance(this);
        this.worldTxt.setAmbient(1, 1, 1, 1);
        this.worldTxt.setDiffuse(0, 0, 0, 1);
        this.worldTxt.setSpecular(0, 0, 0, 1);
        this.worldTxt.setShininess(10.0);
        this.worldTxt.loadTexture('images/earth.jpg');
        this.worldTxt.setTextureWrap('REPEAT', 'REPEAT');

        this.default = new CGFappearance(this);
        this.default.setAmbient(0.2, 0.4, 0.8, 1.0);
        this.default.setDiffuse(0.2, 0.4, 0.8, 1.0);
        this.default.setSpecular(0.2, 0.4, 0.8, 1.0);
        this.default.setShininess(10.0);

        this.landScapeIds = {'Mountain':0, 'Beach':1};
        this.selectedLandScape = 0;

        //Objects connected to MyInterface
        this.displayAxis = true;

        this.displaySphere = false;
        this.displayCylinder = false;
        this.displayPlane = false;
        this.displayVehicle = true;
        this.displayCubeMap = false;
        
        this.displayNormals = false;

        this.scaleFactorVehicle = 1.0;
        this.speedFactorVehicle = 1.0;
    }
    initLights() {
        this.lights[0].setPosition(15, 2, 5, 1);
        this.lights[0].setAmbient(0.7, 0.7, 0.7, 1.0);
        this.lights[0].setDiffuse(1.0, 1.0, 1.0, 1.0);
        this.lights[0].enable();
        this.lights[0].update();
    }
    initCameras() {
        this.camera = new CGFcamera(0.4, 0.1, 500, vec3.fromValues(15, 15, 15), vec3.fromValues(0, 0, 0));
    }
    setDefaultAppearance() {
        this.setAmbient(0.2, 0.4, 0.8, 1.0);
        this.setDiffuse(0.2, 0.4, 0.8, 1.0);
        this.setSpecular(0.2, 0.4, 0.8, 1.0);
        this.setShininess(10.0);
    }
    // called periodically (as per setUpdatePeriod() in init())
    update(t){
        this.checkKeys();
    }

    display() {
        // ---- BEGIN Background, camera and axis setup
        // Clear image and depth buffer everytime we update the scene
        this.gl.viewport(0, 0, this.gl.canvas.width, this.gl.canvas.height);
        this.gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT);
        // Initialize Model-View matrix as identity (no transformation
        this.updateProjectionMatrix();
        this.loadIdentity();
        // Apply transformations corresponding to the camera position relative to the origin
        this.applyViewMatrix();

        
        this.lights[0].update();

        // Draw axis
        if (this.displayAxis){
            this.default.apply();
            this.axis.display();
        }

        //this.setDefaultAppearance();

        //this.lights[1].update();

        // ---- BEGIN Primitive drawing section

        //this.setGlobalAmbientLight(0.8, 0.6, 0.4, 1.0);

        if(this.displayCubeMap){
            this.default.apply();
            if(this.displayNormals)    
                    this.cubeMap.enableNormalViz();
                else    
                    this.cubeMap.disableNormalViz();
            this.cubeMap.display();
        }

        //This sphere does not have defined texture coordinates
        if(this.displaySphere){
            this.default.apply();
            if(this.displayNormals)    
                this.sphere.enableNormalViz();
            else    
                this.sphere.disableNormalViz();

            this.worldTxt.apply();
            this.sphere.display();
        }

        if(this.displayPlane){
            this.default.apply();
            if(this.displayNormals)    
                this.plane.enableNormalViz();
            else    
                this.plane.disableNormalViz();

            this.plane.display();
        }

        if(this.displayCylinder){
            this.default.apply();
            if(this.displayNormals)    
                this.cylinder.enableNormalViz();
            else    
                this.cylinder.disableNormalViz();
            
            this.worldTxt.apply();
            this.cylinder.display();
        }
        

        this.pushMatrix();
        this.scale(this.scaleFactorVehicle, this.scaleFactorVehicle, this.scaleFactorVehicle);
        if(this.displayVehicle){
            this.default.apply();
            this.vehicle.display();
        }
        this.popMatrix();
        

        // ---- END Primitive drawing section
    }

    checkKeys() {
        var text="Keys pressed: ";
        var keysPressed=false;
        
        if (this.gui.isKeyPressed("KeyW")) {
            text+=" W ";
            this.vehicle.accelerate(0.01);
            keysPressed=true;
        }
        
        if (this.gui.isKeyPressed("KeyS")) {
            text+=" S ";
            this.vehicle.accelerate(-0.01);
            keysPressed=true;
        }
        
        if (this.gui.isKeyPressed("KeyA")) {
            text+=" A ";
            this.vehicle.turn(5);
            keysPressed=true;
        }
        
        if (this.gui.isKeyPressed("KeyD")) {
            text+=" D ";
            this.vehicle.turn(-5);
            keysPressed=true;
        }
        
        if (this.gui.isKeyPressed("KeyR")) {
            text+=" R ";
            this.vehicle.reset();
            keysPressed=true;
        }

        if (this.gui.isKeyPressed("KeyP")) {
            text+=" P ";
            this.vehicle.activatePilotoAutomatico();
            keysPressed=true;
        }

        this.vehicle.update();
    }
}
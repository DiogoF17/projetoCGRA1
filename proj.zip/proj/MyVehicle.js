/**
* MyVehicle
* @constructor
*/
class MyVehicle extends CGFobject {
    constructor(scene) {
        super(scene);

        this.triangle = new MyTriangle(scene);

        //this.initMaterials();
    }

    initMaterials(){
        
    }

    display() {

    var ini = [1,0,0,0,
                0,1,0,0,
                0,0,1,0,
                0,0,0,1];

    this.scene.multMatrix(ini);

    this.triangle.display();
    }

    enableNormalViz(){
            this.triangle.enableNormalViz();
    }

    disableNormalViz(){
            this.triangle.disableNormalViz();
    }

    
}